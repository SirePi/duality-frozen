﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Duality;

namespace Tutorial
{
    /// <summary>
    /// Defines a Duality core plugin.
    /// </summary>
    public class TutorialCorePlugin : CorePlugin
    {
        // Override methods here for global logic
    }
}
