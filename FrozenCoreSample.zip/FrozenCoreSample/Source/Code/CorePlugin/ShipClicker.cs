﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Duality.Components.Renderers;
using Duality;
using OpenTK;

namespace Tutorial
{
    [Serializable]
    [RequiredComponent(typeof(SpriteRenderer))]
    public class ShipClicker : FrozenCore.Components.InputReceiverVisual, ICmpUpdatable
    {
        [NonSerialized]
        private Vector2 _movement;

        public override void MouseDown(OpenTK.Input.MouseButtonEventArgs e)
        {
            (GameObj.Renderer as SpriteRenderer).ColorTint = FrozenCore.Colors.Green;
        }

        public override void MouseEnter()
        {
            (GameObj.Renderer as SpriteRenderer).ColorTint = FrozenCore.Colors.Red;
        }

        public override void MouseLeave()
        {
            (GameObj.Renderer as SpriteRenderer).ColorTint = FrozenCore.Colors.White;
        }

        public override void KeyDown(OpenTK.Input.KeyboardKeyEventArgs e, FrozenCore.Components.InputController.ModifierKeys k)
        {
            _movement -= e.Key == OpenTK.Input.Key.Left ? Vector2.UnitX : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Right ? Vector2.UnitX : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Up ? Vector2.UnitY : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Down ? Vector2.UnitY : Vector2.Zero;
        }

        public override void KeyUp(OpenTK.Input.KeyboardKeyEventArgs e, FrozenCore.Components.InputController.ModifierKeys k)
        {
            _movement += e.Key == OpenTK.Input.Key.Left ? Vector2.UnitX : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Right ? Vector2.UnitX : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Up ? Vector2.UnitY : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Down ? Vector2.UnitY : Vector2.Zero;
        }

        void ICmpUpdatable.OnUpdate()
        {
            GameObj.Transform.MoveBy(_movement * Time.TimeMult);
        }
    }
}
