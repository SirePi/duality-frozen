﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Duality.Components.Renderers;
using Duality;
using OpenTK;
using Duality.Components;

namespace Tutorial
{
    [Serializable]
    [RequiredComponent(typeof(Transform))]
    public class Mover : FrozenCore.Components.BaseInputReceiver, ICmpUpdatable
    {
        [NonSerialized]
        private Vector2 _movement;
        
        public override void KeyDown(OpenTK.Input.KeyboardKeyEventArgs e, FrozenCore.Components.InputController.ModifierKeys k)
        {
            _movement -= e.Key == OpenTK.Input.Key.Left ? Vector2.UnitX : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Right ? Vector2.UnitX : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Up ? Vector2.UnitY : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Down ? Vector2.UnitY : Vector2.Zero;
        }

        public override void KeyUp(OpenTK.Input.KeyboardKeyEventArgs e, FrozenCore.Components.InputController.ModifierKeys k)
        {
            _movement += e.Key == OpenTK.Input.Key.Left ? Vector2.UnitX : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Right ? Vector2.UnitX : Vector2.Zero;
            _movement += e.Key == OpenTK.Input.Key.Up ? Vector2.UnitY : Vector2.Zero;
            _movement -= e.Key == OpenTK.Input.Key.Down ? Vector2.UnitY : Vector2.Zero;
        }

        void ICmpUpdatable.OnUpdate()
        {
            GameObj.Transform.MoveBy(_movement * 2 * Time.TimeMult);
        }
    }
}
