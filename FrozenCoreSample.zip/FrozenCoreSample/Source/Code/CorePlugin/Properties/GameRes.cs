/*
 * A set of static helper classes that provide easy runtime access to the games resources.
 * This file is auto-generated. Any changes made to it are lost as soon as Duality decides
 * to regenerate it.
 */
namespace GameRes
{
	public static class Data {
		public static Duality.ContentRef<Duality.Resources.Scene> MainScene_Scene { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Scene>(@"Data\MainScene.Scene.res"); }}
		public static Duality.ContentRef<Duality.Resources.Material> ShipOne_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\ShipOne.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> ShipOne_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\ShipOne.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> ShipOne_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\ShipOne.Texture.res"); }}
		public static Duality.ContentRef<Duality.Resources.Material> system_Material { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Material>(@"Data\system.Material.res"); }}
		public static Duality.ContentRef<Duality.Resources.Pixmap> system_Pixmap { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Pixmap>(@"Data\system.Pixmap.res"); }}
		public static Duality.ContentRef<Duality.Resources.Texture> system_Texture { get { return Duality.ContentProvider.RequestContent<Duality.Resources.Texture>(@"Data\system.Texture.res"); }}
		public static void LoadAll() {
			MainScene_Scene.MakeAvailable();
			ShipOne_Material.MakeAvailable();
			ShipOne_Pixmap.MakeAvailable();
			ShipOne_Texture.MakeAvailable();
			system_Material.MakeAvailable();
			system_Pixmap.MakeAvailable();
			system_Texture.MakeAvailable();
		}
	}

}
