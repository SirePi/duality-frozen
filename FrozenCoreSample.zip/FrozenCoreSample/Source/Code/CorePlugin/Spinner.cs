﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Duality;
using Duality.Components;

namespace Tutorial
{
    [Serializable]
    [RequiredComponent(typeof(Transform))]
    public class Spinner : Component, ICmpUpdatable
    {
        public float RotationSpeed { get; set; }

        void ICmpUpdatable.OnUpdate()
        {
            float a = GameObj.Transform.Angle + (MathF.DegToRad(RotationSpeed) * Time.TimeMult);
            GameObj.Transform.Angle = (a % MathF.TwoPi);
        }
    }
}
